import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// =============================================================================
// TYPES
// =============================================================================

export type ThemeMode = 'light' | 'dark' | 'system';
export type AccentColor = 'emerald' | 'blue' | 'violet' | 'rose' | 'amber' | 'cyan' | 'orange';
export type SidebarMode = 'expanded' | 'collapsed' | 'autohide';
export type Language = 'en' | 'de' | 'es' | 'fr';

export interface AccentColorConfig {
  name: string;
  value: AccentColor;
  primary: string;
  primaryHover: string;
  primaryLight: string;
  gradient: string;
}

export interface LanguageConfig {
  code: Language;
  name: string;
  nativeName: string;
  flag: string;
}

// =============================================================================
// LANGUAGE CONFIGURATIONS
// =============================================================================

export const languages: LanguageConfig[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
];

// =============================================================================
// TRANSLATIONS
// =============================================================================

export const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.transactions': 'Transactions',
    'nav.accounts': 'Accounts',
    'nav.wallet': 'Wallet',
    'nav.receipts': 'Receipts',
    'nav.reports': 'Reports',
    'nav.taxCenter': 'Tax Center',
    'nav.aiAssistant': 'AI Assistant',
    'nav.teamChat': 'Team Chat',
    'nav.settings': 'Settings',
    'nav.main': 'Main',
    'nav.tools': 'Tools',
    
    // Settings
    'settings.title': 'Settings',
    'settings.subtitle': 'Manage your account and preferences',
    'settings.save': 'Save Changes',
    'settings.saved': 'Saved!',
    
    // Settings Tabs
    'settings.tabs.profile': 'Profile',
    'settings.tabs.organization': 'Organization',
    'settings.tabs.notifications': 'Notifications',
    'settings.tabs.security': 'Security',
    'settings.tabs.billing': 'Billing',
    'settings.tabs.integrations': 'Integrations',
    'settings.tabs.appearance': 'Appearance',
    
    // Appearance
    'appearance.theme': 'Theme',
    'appearance.themeDesc': 'Choose how PrimeBalance looks to you',
    'appearance.light': 'Light',
    'appearance.lightDesc': 'Light background with dark text',
    'appearance.dark': 'Dark',
    'appearance.darkDesc': 'Dark background with light text',
    'appearance.system': 'System',
    'appearance.systemDesc': 'Match your system settings',
    'appearance.accentColor': 'Accent Color',
    'appearance.accentColorDesc': 'Select your preferred accent color',
    'appearance.sidebar': 'Sidebar',
    'appearance.sidebarDesc': 'Choose how the sidebar behaves',
    'appearance.expanded': 'Expanded',
    'appearance.expandedDesc': 'Full sidebar with labels',
    'appearance.collapsed': 'Collapsed',
    'appearance.collapsedDesc': 'Compact icons only',
    'appearance.autohide': 'Auto-hide',
    'appearance.autohideDesc': 'Show on hover',
    'appearance.language': 'Language',
    'appearance.languageDesc': 'Select your preferred language',
    'appearance.preview': 'Preview',
    'appearance.currentSettings': 'Current Settings',
    'appearance.primaryButton': 'Primary Button',
    'appearance.secondary': 'Secondary',
    
    // Profile
    'profile.personalInfo': 'Personal Information',
    'profile.firstName': 'First Name',
    'profile.lastName': 'Last Name',
    'profile.email': 'Email',
    'profile.phone': 'Phone Number',
    'profile.timezone': 'Timezone',
    
    // Organization
    'org.details': 'Organization Details',
    'org.companyName': 'Company Name',
    'org.industry': 'Industry',
    'org.companySize': 'Company Size',
    
    // Notifications
    'notifications.preferences': 'Notification Preferences',
    'notifications.transactionAlerts': 'Transaction alerts',
    'notifications.transactionAlertsDesc': 'Get notified for all transactions',
    'notifications.weeklyReports': 'Weekly reports',
    'notifications.weeklyReportsDesc': 'Receive weekly financial summary',
    'notifications.taxReminders': 'Tax reminders',
    'notifications.taxRemindersDesc': 'Upcoming tax deadlines',
    'notifications.teamUpdates': 'Team updates',
    'notifications.teamUpdatesDesc': 'When team members make changes',
    
    // Security
    'security.password': 'Password',
    'security.currentPassword': 'Current Password',
    'security.newPassword': 'New Password',
    'security.confirmPassword': 'Confirm Password',
    'security.twoFactor': 'Two-Factor Authentication',
    'security.authenticatorApp': 'Authenticator App',
    'security.authenticatorAppDesc': 'Use an app to generate codes',
    'security.enable': 'Enable',
    
    // Billing
    'billing.currentPlan': 'Current Plan',
    'billing.professionalPlan': 'Professional Plan',
    'billing.upgrade': 'Upgrade',
    'billing.paymentMethod': 'Payment Method',
    'billing.update': 'Update',
    
    // Integrations
    'integrations.connectedServices': 'Connected Services',
    'integrations.connected': 'Connected',
    'integrations.connect': 'Connect',
    
    // Header
    'header.search': 'Search transactions, accounts, reports...',
    'header.newTransaction': 'New Transaction',
    'header.new': 'New',
    'header.notifications': 'Notifications',
    'header.markAllRead': 'Mark all read',
    'header.viewAll': 'View all notifications',
    'header.profileSettings': 'Profile Settings',
    'header.accountSettings': 'Account Settings',
    'header.billingReports': 'Billing & Reports',
    'header.signOut': 'Sign out',
    
    // Common
    'common.user': 'User',
    'common.organization': 'Organization',
  },
  
  de: {
    // Navigation
    'nav.dashboard': 'Übersicht',
    'nav.transactions': 'Transaktionen',
    'nav.accounts': 'Konten',
    'nav.wallet': 'Wallet',
    'nav.receipts': 'Belege',
    'nav.reports': 'Berichte',
    'nav.taxCenter': 'Steuerzentrale',
    'nav.aiAssistant': 'KI-Assistent',
    'nav.teamChat': 'Team-Chat',
    'nav.settings': 'Einstellungen',
    'nav.main': 'Hauptmenü',
    'nav.tools': 'Werkzeuge',
    
    // Settings
    'settings.title': 'Einstellungen',
    'settings.subtitle': 'Verwalten Sie Ihr Konto und Ihre Präferenzen',
    'settings.save': 'Änderungen speichern',
    'settings.saved': 'Gespeichert!',
    
    // Settings Tabs
    'settings.tabs.profile': 'Profil',
    'settings.tabs.organization': 'Organisation',
    'settings.tabs.notifications': 'Benachrichtigungen',
    'settings.tabs.security': 'Sicherheit',
    'settings.tabs.billing': 'Abrechnung',
    'settings.tabs.integrations': 'Integrationen',
    'settings.tabs.appearance': 'Erscheinungsbild',
    
    // Appearance
    'appearance.theme': 'Design',
    'appearance.themeDesc': 'Wählen Sie das Erscheinungsbild von PrimeBalance',
    'appearance.light': 'Hell',
    'appearance.lightDesc': 'Heller Hintergrund mit dunklem Text',
    'appearance.dark': 'Dunkel',
    'appearance.darkDesc': 'Dunkler Hintergrund mit hellem Text',
    'appearance.system': 'System',
    'appearance.systemDesc': 'Systemeinstellung übernehmen',
    'appearance.accentColor': 'Akzentfarbe',
    'appearance.accentColorDesc': 'Wählen Sie Ihre bevorzugte Akzentfarbe',
    'appearance.sidebar': 'Seitenleiste',
    'appearance.sidebarDesc': 'Wählen Sie das Verhalten der Seitenleiste',
    'appearance.expanded': 'Erweitert',
    'appearance.expandedDesc': 'Volle Seitenleiste mit Beschriftungen',
    'appearance.collapsed': 'Kompakt',
    'appearance.collapsedDesc': 'Nur kompakte Symbole',
    'appearance.autohide': 'Automatisch ausblenden',
    'appearance.autohideDesc': 'Bei Hover anzeigen',
    'appearance.language': 'Sprache',
    'appearance.languageDesc': 'Wählen Sie Ihre bevorzugte Sprache',
    'appearance.preview': 'Vorschau',
    'appearance.currentSettings': 'Aktuelle Einstellungen',
    'appearance.primaryButton': 'Primäre Schaltfläche',
    'appearance.secondary': 'Sekundär',
    
    // Profile
    'profile.personalInfo': 'Persönliche Informationen',
    'profile.firstName': 'Vorname',
    'profile.lastName': 'Nachname',
    'profile.email': 'E-Mail',
    'profile.phone': 'Telefonnummer',
    'profile.timezone': 'Zeitzone',
    
    // Organization
    'org.details': 'Organisationsdetails',
    'org.companyName': 'Firmenname',
    'org.industry': 'Branche',
    'org.companySize': 'Unternehmensgröße',
    
    // Notifications
    'notifications.preferences': 'Benachrichtigungseinstellungen',
    'notifications.transactionAlerts': 'Transaktionsbenachrichtigungen',
    'notifications.transactionAlertsDesc': 'Bei allen Transaktionen benachrichtigen',
    'notifications.weeklyReports': 'Wochenberichte',
    'notifications.weeklyReportsDesc': 'Wöchentliche Finanzzusammenfassung erhalten',
    'notifications.taxReminders': 'Steuererinnerungen',
    'notifications.taxRemindersDesc': 'Anstehende Steuerfristen',
    'notifications.teamUpdates': 'Team-Updates',
    'notifications.teamUpdatesDesc': 'Wenn Teammitglieder Änderungen vornehmen',
    
    // Security
    'security.password': 'Passwort',
    'security.currentPassword': 'Aktuelles Passwort',
    'security.newPassword': 'Neues Passwort',
    'security.confirmPassword': 'Passwort bestätigen',
    'security.twoFactor': 'Zwei-Faktor-Authentifizierung',
    'security.authenticatorApp': 'Authenticator-App',
    'security.authenticatorAppDesc': 'Eine App zur Code-Generierung verwenden',
    'security.enable': 'Aktivieren',
    
    // Billing
    'billing.currentPlan': 'Aktueller Tarif',
    'billing.professionalPlan': 'Professional-Tarif',
    'billing.upgrade': 'Upgrade',
    'billing.paymentMethod': 'Zahlungsmethode',
    'billing.update': 'Aktualisieren',
    
    // Integrations
    'integrations.connectedServices': 'Verbundene Dienste',
    'integrations.connected': 'Verbunden',
    'integrations.connect': 'Verbinden',
    
    // Header
    'header.search': 'Transaktionen, Konten, Berichte suchen...',
    'header.newTransaction': 'Neue Transaktion',
    'header.new': 'Neu',
    'header.notifications': 'Benachrichtigungen',
    'header.markAllRead': 'Alle als gelesen markieren',
    'header.viewAll': 'Alle Benachrichtigungen anzeigen',
    'header.profileSettings': 'Profileinstellungen',
    'header.accountSettings': 'Kontoeinstellungen',
    'header.billingReports': 'Abrechnung & Berichte',
    'header.signOut': 'Abmelden',
    
    // Common
    'common.user': 'Benutzer',
    'common.organization': 'Organisation',
  },
  
  es: {
    // Navigation
    'nav.dashboard': 'Panel',
    'nav.transactions': 'Transacciones',
    'nav.accounts': 'Cuentas',
    'nav.wallet': 'Billetera',
    'nav.receipts': 'Recibos',
    'nav.reports': 'Informes',
    'nav.taxCenter': 'Centro de Impuestos',
    'nav.aiAssistant': 'Asistente IA',
    'nav.teamChat': 'Chat de Equipo',
    'nav.settings': 'Configuración',
    'nav.main': 'Principal',
    'nav.tools': 'Herramientas',
    
    // Settings
    'settings.title': 'Configuración',
    'settings.subtitle': 'Administra tu cuenta y preferencias',
    'settings.save': 'Guardar Cambios',
    'settings.saved': '¡Guardado!',
    
    // Settings Tabs
    'settings.tabs.profile': 'Perfil',
    'settings.tabs.organization': 'Organización',
    'settings.tabs.notifications': 'Notificaciones',
    'settings.tabs.security': 'Seguridad',
    'settings.tabs.billing': 'Facturación',
    'settings.tabs.integrations': 'Integraciones',
    'settings.tabs.appearance': 'Apariencia',
    
    // Appearance
    'appearance.theme': 'Tema',
    'appearance.themeDesc': 'Elige cómo se ve PrimeBalance para ti',
    'appearance.light': 'Claro',
    'appearance.lightDesc': 'Fondo claro con texto oscuro',
    'appearance.dark': 'Oscuro',
    'appearance.darkDesc': 'Fondo oscuro con texto claro',
    'appearance.system': 'Sistema',
    'appearance.systemDesc': 'Coincidir con la configuración del sistema',
    'appearance.accentColor': 'Color de Acento',
    'appearance.accentColorDesc': 'Selecciona tu color de acento preferido',
    'appearance.sidebar': 'Barra Lateral',
    'appearance.sidebarDesc': 'Elige cómo se comporta la barra lateral',
    'appearance.expanded': 'Expandida',
    'appearance.expandedDesc': 'Barra lateral completa con etiquetas',
    'appearance.collapsed': 'Compacta',
    'appearance.collapsedDesc': 'Solo iconos compactos',
    'appearance.autohide': 'Auto-ocultar',
    'appearance.autohideDesc': 'Mostrar al pasar el cursor',
    'appearance.language': 'Idioma',
    'appearance.languageDesc': 'Selecciona tu idioma preferido',
    'appearance.preview': 'Vista Previa',
    'appearance.currentSettings': 'Configuración Actual',
    'appearance.primaryButton': 'Botón Primario',
    'appearance.secondary': 'Secundario',
    
    // Profile
    'profile.personalInfo': 'Información Personal',
    'profile.firstName': 'Nombre',
    'profile.lastName': 'Apellido',
    'profile.email': 'Correo Electrónico',
    'profile.phone': 'Número de Teléfono',
    'profile.timezone': 'Zona Horaria',
    
    // Organization
    'org.details': 'Detalles de la Organización',
    'org.companyName': 'Nombre de la Empresa',
    'org.industry': 'Industria',
    'org.companySize': 'Tamaño de la Empresa',
    
    // Notifications
    'notifications.preferences': 'Preferencias de Notificación',
    'notifications.transactionAlerts': 'Alertas de transacciones',
    'notifications.transactionAlertsDesc': 'Recibir notificaciones de todas las transacciones',
    'notifications.weeklyReports': 'Informes semanales',
    'notifications.weeklyReportsDesc': 'Recibir resumen financiero semanal',
    'notifications.taxReminders': 'Recordatorios de impuestos',
    'notifications.taxRemindersDesc': 'Próximas fechas límite de impuestos',
    'notifications.teamUpdates': 'Actualizaciones del equipo',
    'notifications.teamUpdatesDesc': 'Cuando los miembros del equipo hacen cambios',
    
    // Security
    'security.password': 'Contraseña',
    'security.currentPassword': 'Contraseña Actual',
    'security.newPassword': 'Nueva Contraseña',
    'security.confirmPassword': 'Confirmar Contraseña',
    'security.twoFactor': 'Autenticación de Dos Factores',
    'security.authenticatorApp': 'App de Autenticación',
    'security.authenticatorAppDesc': 'Usar una app para generar códigos',
    'security.enable': 'Activar',
    
    // Billing
    'billing.currentPlan': 'Plan Actual',
    'billing.professionalPlan': 'Plan Profesional',
    'billing.upgrade': 'Mejorar',
    'billing.paymentMethod': 'Método de Pago',
    'billing.update': 'Actualizar',
    
    // Integrations
    'integrations.connectedServices': 'Servicios Conectados',
    'integrations.connected': 'Conectado',
    'integrations.connect': 'Conectar',
    
    // Header
    'header.search': 'Buscar transacciones, cuentas, informes...',
    'header.newTransaction': 'Nueva Transacción',
    'header.new': 'Nuevo',
    'header.notifications': 'Notificaciones',
    'header.markAllRead': 'Marcar todo como leído',
    'header.viewAll': 'Ver todas las notificaciones',
    'header.profileSettings': 'Configuración de Perfil',
    'header.accountSettings': 'Configuración de Cuenta',
    'header.billingReports': 'Facturación e Informes',
    'header.signOut': 'Cerrar sesión',
    
    // Common
    'common.user': 'Usuario',
    'common.organization': 'Organización',
  },
  
  fr: {
    // Navigation
    'nav.dashboard': 'Tableau de bord',
    'nav.transactions': 'Transactions',
    'nav.accounts': 'Comptes',
    'nav.wallet': 'Portefeuille',
    'nav.receipts': 'Reçus',
    'nav.reports': 'Rapports',
    'nav.taxCenter': 'Centre Fiscal',
    'nav.aiAssistant': 'Assistant IA',
    'nav.teamChat': 'Chat d\'Équipe',
    'nav.settings': 'Paramètres',
    'nav.main': 'Principal',
    'nav.tools': 'Outils',
    
    // Settings
    'settings.title': 'Paramètres',
    'settings.subtitle': 'Gérez votre compte et vos préférences',
    'settings.save': 'Enregistrer',
    'settings.saved': 'Enregistré !',
    
    // Settings Tabs
    'settings.tabs.profile': 'Profil',
    'settings.tabs.organization': 'Organisation',
    'settings.tabs.notifications': 'Notifications',
    'settings.tabs.security': 'Sécurité',
    'settings.tabs.billing': 'Facturation',
    'settings.tabs.integrations': 'Intégrations',
    'settings.tabs.appearance': 'Apparence',
    
    // Appearance
    'appearance.theme': 'Thème',
    'appearance.themeDesc': 'Choisissez l\'apparence de PrimeBalance',
    'appearance.light': 'Clair',
    'appearance.lightDesc': 'Fond clair avec texte sombre',
    'appearance.dark': 'Sombre',
    'appearance.darkDesc': 'Fond sombre avec texte clair',
    'appearance.system': 'Système',
    'appearance.systemDesc': 'Suivre les paramètres système',
    'appearance.accentColor': 'Couleur d\'Accent',
    'appearance.accentColorDesc': 'Sélectionnez votre couleur d\'accent préférée',
    'appearance.sidebar': 'Barre Latérale',
    'appearance.sidebarDesc': 'Choisissez le comportement de la barre latérale',
    'appearance.expanded': 'Étendue',
    'appearance.expandedDesc': 'Barre latérale complète avec libellés',
    'appearance.collapsed': 'Réduite',
    'appearance.collapsedDesc': 'Icônes compactes uniquement',
    'appearance.autohide': 'Masquage auto',
    'appearance.autohideDesc': 'Afficher au survol',
    'appearance.language': 'Langue',
    'appearance.languageDesc': 'Sélectionnez votre langue préférée',
    'appearance.preview': 'Aperçu',
    'appearance.currentSettings': 'Paramètres Actuels',
    'appearance.primaryButton': 'Bouton Principal',
    'appearance.secondary': 'Secondaire',
    
    // Profile
    'profile.personalInfo': 'Informations Personnelles',
    'profile.firstName': 'Prénom',
    'profile.lastName': 'Nom',
    'profile.email': 'E-mail',
    'profile.phone': 'Numéro de Téléphone',
    'profile.timezone': 'Fuseau Horaire',
    
    // Organization
    'org.details': 'Détails de l\'Organisation',
    'org.companyName': 'Nom de l\'Entreprise',
    'org.industry': 'Secteur',
    'org.companySize': 'Taille de l\'Entreprise',
    
    // Notifications
    'notifications.preferences': 'Préférences de Notification',
    'notifications.transactionAlerts': 'Alertes de transactions',
    'notifications.transactionAlertsDesc': 'Être notifié pour toutes les transactions',
    'notifications.weeklyReports': 'Rapports hebdomadaires',
    'notifications.weeklyReportsDesc': 'Recevoir un résumé financier hebdomadaire',
    'notifications.taxReminders': 'Rappels fiscaux',
    'notifications.taxRemindersDesc': 'Échéances fiscales à venir',
    'notifications.teamUpdates': 'Mises à jour de l\'équipe',
    'notifications.teamUpdatesDesc': 'Quand les membres de l\'équipe font des changements',
    
    // Security
    'security.password': 'Mot de Passe',
    'security.currentPassword': 'Mot de Passe Actuel',
    'security.newPassword': 'Nouveau Mot de Passe',
    'security.confirmPassword': 'Confirmer le Mot de Passe',
    'security.twoFactor': 'Authentification à Deux Facteurs',
    'security.authenticatorApp': 'Application d\'Authentification',
    'security.authenticatorAppDesc': 'Utiliser une app pour générer des codes',
    'security.enable': 'Activer',
    
    // Billing
    'billing.currentPlan': 'Forfait Actuel',
    'billing.professionalPlan': 'Forfait Professionnel',
    'billing.upgrade': 'Améliorer',
    'billing.paymentMethod': 'Moyen de Paiement',
    'billing.update': 'Mettre à jour',
    
    // Integrations
    'integrations.connectedServices': 'Services Connectés',
    'integrations.connected': 'Connecté',
    'integrations.connect': 'Connecter',
    
    // Header
    'header.search': 'Rechercher transactions, comptes, rapports...',
    'header.newTransaction': 'Nouvelle Transaction',
    'header.new': 'Nouveau',
    'header.notifications': 'Notifications',
    'header.markAllRead': 'Tout marquer comme lu',
    'header.viewAll': 'Voir toutes les notifications',
    'header.profileSettings': 'Paramètres du Profil',
    'header.accountSettings': 'Paramètres du Compte',
    'header.billingReports': 'Facturation & Rapports',
    'header.signOut': 'Déconnexion',
    
    // Common
    'common.user': 'Utilisateur',
    'common.organization': 'Organisation',
  },
};

// =============================================================================
// ACCENT COLOR CONFIGURATIONS
// =============================================================================

export const accentColors: AccentColorConfig[] = [
  {
    name: 'Emerald',
    value: 'emerald',
    primary: '#10b981',
    primaryHover: '#059669',
    primaryLight: '#d1fae5',
    gradient: 'from-emerald-500 to-teal-500',
  },
  {
    name: 'Blue',
    value: 'blue',
    primary: '#3b82f6',
    primaryHover: '#2563eb',
    primaryLight: '#dbeafe',
    gradient: 'from-blue-500 to-cyan-500',
  },
  {
    name: 'Violet',
    value: 'violet',
    primary: '#8b5cf6',
    primaryHover: '#7c3aed',
    primaryLight: '#ede9fe',
    gradient: 'from-violet-500 to-purple-500',
  },
  {
    name: 'Rose',
    value: 'rose',
    primary: '#f43f5e',
    primaryHover: '#e11d48',
    primaryLight: '#ffe4e6',
    gradient: 'from-rose-500 to-pink-500',
  },
  {
    name: 'Amber',
    value: 'amber',
    primary: '#f59e0b',
    primaryHover: '#d97706',
    primaryLight: '#fef3c7',
    gradient: 'from-amber-500 to-orange-500',
  },
  {
    name: 'Cyan',
    value: 'cyan',
    primary: '#06b6d4',
    primaryHover: '#0891b2',
    primaryLight: '#cffafe',
    gradient: 'from-cyan-500 to-teal-500',
  },
  {
    name: 'Orange',
    value: 'orange',
    primary: '#f97316',
    primaryHover: '#ea580c',
    primaryLight: '#ffedd5',
    gradient: 'from-orange-500 to-red-500',
  },
];

// =============================================================================
// STORE INTERFACE
// =============================================================================

interface ThemeState {
  // Theme settings
  themeMode: ThemeMode;
  accentColor: AccentColor;
  sidebarMode: SidebarMode;
  language: Language;
  
  // Computed states
  resolvedTheme: 'light' | 'dark';
  sidebarExpanded: boolean;
  sidebarHovered: boolean;
  
  // Actions
  setThemeMode: (mode: ThemeMode) => void;
  setAccentColor: (color: AccentColor) => void;
  setSidebarMode: (mode: SidebarMode) => void;
  setLanguage: (lang: Language) => void;
  setSidebarExpanded: (expanded: boolean) => void;
  setSidebarHovered: (hovered: boolean) => void;
  toggleSidebar: () => void;
  
  // Helpers
  getAccentConfig: () => AccentColorConfig;
  getSidebarWidth: () => number;
  t: (key: string) => string;
}

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function getSystemTheme(): 'light' | 'dark' {
  if (typeof window === 'undefined') return 'dark';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function resolveTheme(mode: ThemeMode): 'light' | 'dark' {
  if (mode === 'system') {
    return getSystemTheme();
  }
  return mode;
}

// =============================================================================
// STORE IMPLEMENTATION
// =============================================================================

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      // Initial state
      themeMode: 'dark',
      accentColor: 'emerald',
      sidebarMode: 'expanded',
      language: 'en',
      resolvedTheme: 'dark',
      sidebarExpanded: true,
      sidebarHovered: false,
      
      // Theme mode
      setThemeMode: (mode) => {
        const resolved = resolveTheme(mode);
        set({ themeMode: mode, resolvedTheme: resolved });
        
        // Apply to document
        if (typeof document !== 'undefined') {
          const root = document.documentElement;
          root.classList.remove('light', 'dark');
          root.classList.add(resolved);
          root.setAttribute('data-theme', resolved);
        }
      },
      
      // Accent color
      setAccentColor: (color) => {
        set({ accentColor: color });
        
        // Apply CSS variables
        if (typeof document !== 'undefined') {
          const config = accentColors.find(c => c.value === color);
          if (config) {
            const root = document.documentElement;
            root.style.setProperty('--accent-primary', config.primary);
            root.style.setProperty('--accent-primary-hover', config.primaryHover);
            root.style.setProperty('--accent-primary-light', config.primaryLight);
            root.setAttribute('data-accent', color);
          }
        }
      },
      
      // Language
      setLanguage: (lang) => {
        set({ language: lang });
        
        // Apply to document
        if (typeof document !== 'undefined') {
          document.documentElement.setAttribute('lang', lang);
        }
      },
      
      // Sidebar mode
      setSidebarMode: (mode) => {
        set({ 
          sidebarMode: mode,
          sidebarExpanded: mode === 'expanded',
        });
      },
      
      setSidebarExpanded: (expanded) => {
        set({ sidebarExpanded: expanded });
      },
      
      setSidebarHovered: (hovered) => {
        const { sidebarMode } = get();
        if (sidebarMode === 'autohide') {
          set({ sidebarExpanded: hovered, sidebarHovered: hovered });
        } else {
          set({ sidebarHovered: hovered });
        }
      },
      
      toggleSidebar: () => {
        const { sidebarMode, sidebarExpanded } = get();
        if (sidebarMode === 'collapsed' || sidebarMode === 'expanded') {
          set({ 
            sidebarMode: sidebarExpanded ? 'collapsed' : 'expanded',
            sidebarExpanded: !sidebarExpanded 
          });
        }
      },
      
      // Helpers
      getAccentConfig: () => {
        const { accentColor } = get();
        return accentColors.find(c => c.value === accentColor) || accentColors[0];
      },
      
      getSidebarWidth: () => {
        const { sidebarMode, sidebarExpanded, sidebarHovered } = get();
        
        if (sidebarMode === 'expanded') return 288; // 72 * 4 = w-72
        if (sidebarMode === 'collapsed') return 80; // w-20
        if (sidebarMode === 'autohide') {
          return sidebarHovered ? 288 : 0;
        }
        return sidebarExpanded ? 288 : 80;
      },
      
      // Translation helper
      t: (key: string) => {
        const { language } = get();
        return translations[language]?.[key] || translations['en'][key] || key;
      },
    }),
    {
      name: 'primebalance-theme',
      partialize: (state) => ({
        themeMode: state.themeMode,
        accentColor: state.accentColor,
        sidebarMode: state.sidebarMode,
        language: state.language,
      }),
    }
  )
);

// =============================================================================
// INITIALIZATION HOOK
// =============================================================================

export function initializeTheme() {
  const store = useThemeStore.getState();
  
  // Apply theme
  store.setThemeMode(store.themeMode);
  store.setAccentColor(store.accentColor);
  
  // Listen for system theme changes
  if (typeof window !== 'undefined') {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    mediaQuery.addEventListener('change', (e) => {
      if (store.themeMode === 'system') {
        const resolved = e.matches ? 'dark' : 'light';
        useThemeStore.setState({ resolvedTheme: resolved });
        document.documentElement.classList.remove('light', 'dark');
        document.documentElement.classList.add(resolved);
      }
    });
  }
}
