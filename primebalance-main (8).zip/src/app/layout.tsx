import type { Metadata, Viewport } from 'next'
import './globals.css'
import { Toaster } from 'react-hot-toast'
import AuthProvider from '@/components/providers/AuthProvider'
import ThemeProvider from '@/components/providers/ThemeProvider'

export const metadata: Metadata = {
  title: 'PrimeBalance | Next-Gen Accounting Platform',
  description: 'AI-powered accounting software with blockchain integration for modern businesses',
  keywords: ['accounting', 'bookkeeping', 'fintech', 'blockchain', 'crypto', 'AI', 'automation'],
  authors: [{ name: 'PrimeBalance Team' }],
  icons: {
    icon: '/favicon.svg',
  },
  openGraph: {
    title: 'PrimeBalance | Next-Gen Accounting Platform',
    description: 'AI-powered accounting software with blockchain integration',
    url: 'https://primebalance.app',
    siteName: 'PrimeBalance',
    locale: 'en_US',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#0f1115',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  const stored = localStorage.getItem('primebalance-theme');
                  if (stored) {
                    const { state } = JSON.parse(stored);
                    const theme = state.themeMode;
                    const accent = state.accentColor || 'emerald';
                    
                    let resolved = theme;
                    if (theme === 'system') {
                      resolved = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
                    }
                    
                    document.documentElement.classList.remove('light', 'dark');
                    document.documentElement.classList.add(resolved);
                    document.documentElement.setAttribute('data-theme', resolved);
                    document.documentElement.setAttribute('data-accent', accent);
                  }
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>
      <body className="noise-overlay bg-gray-50 dark:bg-surface-950 text-gray-900 dark:text-white transition-colors">
        <AuthProvider>
          <ThemeProvider>
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 4000,
                style: {
                  background: 'rgba(52, 58, 70, 0.95)',
                  color: '#f6f7f9',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  borderRadius: '12px',
                  backdropFilter: 'blur(10px)',
                },
                success: {
                  iconTheme: {
                    primary: '#14d47a',
                    secondary: '#0f1115',
                  },
                },
                error: {
                  iconTheme: {
                    primary: '#ef4444',
                    secondary: '#0f1115',
                  },
                },
              }}
            />
            {children}
          </ThemeProvider>
        </AuthProvider>
      </body>
    </html>
  )
}