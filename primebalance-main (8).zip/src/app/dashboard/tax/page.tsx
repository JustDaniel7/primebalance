'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2,
  Globe,
  Lightbulb,
  FileText,
  Bell,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Calendar,
  MapPin,
  Percent,
  Search,
  Filter,
  Download,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Info,
  BarChart3,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Settings,
  X,
  Sparkles,
  Calculator,
  ChevronDown,
} from 'lucide-react';
import { CorporateStructureEditor, TaxOptimizationPanel } from '@/components/tax';
import { useTaxStore, initializeDemoTaxData } from '@/store/tax-store';
import {
  ALL_JURISDICTIONS,
  getJurisdiction,
  getGroupedJurisdictions,
  calculateCorporateTax,
  compareJurisdictions,
  getNoIncomeTaxStates,
  getLowTaxJurisdictions,
} from '@/data/jurisdictions';
import { TaxJurisdictionFull, JurisdictionType } from '@/types/tax';

// =============================================================================
// TAB NAVIGATION
// =============================================================================

type TabId = 'overview' | 'structure' | 'jurisdictions' | 'optimization';

interface Tab {
  id: TabId;
  label: string;
  icon: React.ElementType;
}

const tabs: Tab[] = [
  { id: 'overview', label: 'Overview', icon: BarChart3 },
  { id: 'structure', label: 'Corporate Structure', icon: Building2 },
  { id: 'jurisdictions', label: 'Jurisdictions', icon: Globe },
  { id: 'optimization', label: 'Optimization', icon: Lightbulb },
];

// =============================================================================
// OVERVIEW TAB COMPONENT
// =============================================================================

const OverviewTab: React.FC = () => {
  const { getActiveStructure, notifications, optimizationResult } = useTaxStore();
  const structure = getActiveStructure();

  // Calculate summary stats
  const jurisdictionCount = useMemo(() => {
    if (!structure) return 0;
    return new Set(structure.entities.map(e => e.jurisdictionCode)).size;
  }, [structure]);

  const entityCount = structure?.entities.length || 0;

  const upcomingDeadlines = useMemo(() => {
    return notifications
      .filter(n => n.category === 'DEADLINE' && !n.dismissed)
      .slice(0, 5);
  }, [notifications]);

  const unreadNotifications = notifications.filter(n => !n.read && !n.dismissed);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl p-5 border border-white/10"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Entities</p>
              <p className="text-2xl font-bold text-white mt-1">
                {entityCount}
              </p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Building2 className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl p-5 border border-white/10"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Jurisdictions</p>
              <p className="text-2xl font-bold text-white mt-1">
                {jurisdictionCount}
              </p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <Globe className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl p-5 border border-white/10"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Optimization Opportunities</p>
              <p className="text-2xl font-bold text-emerald-400 mt-1">
                {optimizationResult?.suggestions.length || 0}
              </p>
            </div>
            <div className="p-3 bg-emerald-500/20 rounded-lg">
              <Lightbulb className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl p-5 border border-white/10"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Alerts</p>
              <p className="text-2xl font-bold text-orange-400 mt-1">
                {unreadNotifications.length}
              </p>
            </div>
            <div className="p-3 bg-orange-500/20 rounded-lg">
              <Bell className="w-6 h-6 text-orange-400" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Deadlines */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10"
        >
          <div className="p-4 border-b border-white/10">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              Upcoming Deadlines
            </h3>
          </div>
          <div className="p-4">
            {upcomingDeadlines.length > 0 ? (
              <div className="space-y-3">
                {upcomingDeadlines.map((deadline) => {
                  const jurisdiction = deadline.relatedJurisdiction 
                    ? getJurisdiction(deadline.relatedJurisdiction)
                    : null;
                  
                  return (
                    <div
                      key={deadline.id}
                      className="flex items-center justify-between p-3 bg-white/5 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${
                          deadline.priority === 'CRITICAL' || deadline.priority === 'HIGH'
                            ? 'bg-red-500/20'
                            : 'bg-yellow-500/20'
                        }`}>
                          <Clock className={`w-4 h-4 ${
                            deadline.priority === 'CRITICAL' || deadline.priority === 'HIGH'
                              ? 'text-red-400'
                              : 'text-yellow-400'
                          }`} />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-white">
                            {deadline.title}
                          </p>
                          <p className="text-xs text-gray-500">
                            {jurisdiction?.flag} {jurisdiction?.shortName || deadline.relatedJurisdiction}
                          </p>
                        </div>
                      </div>
                      {deadline.dueDate && (
                        <span className="text-xs text-gray-500">
                          {new Date(deadline.dueDate).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">
                No upcoming deadlines
              </p>
            )}
          </div>
        </motion.div>

        {/* Recent Alerts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10"
        >
          <div className="p-4 border-b border-white/10">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-orange-400" />
              Recent Alerts
            </h3>
          </div>
          <div className="p-4">
            {unreadNotifications.length > 0 ? (
              <div className="space-y-3">
                {unreadNotifications.slice(0, 5).map((notification) => (
                  <div
                    key={notification.id}
                    className="flex items-start gap-3 p-3 bg-white/5 rounded-lg"
                  >
                    <div className={`p-2 rounded-lg ${
                      notification.priority === 'CRITICAL' || notification.priority === 'HIGH'
                        ? 'bg-red-500/20'
                        : notification.category === 'OPTIMIZATION'
                        ? 'bg-green-500/20'
                        : 'bg-blue-500/20'
                    }`}>
                      {notification.category === 'OPTIMIZATION' ? (
                        <Lightbulb className="w-4 h-4 text-green-400" />
                      ) : notification.category === 'COMPLIANCE' ? (
                        <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      ) : (
                        <Info className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">
                        {notification.title}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {notification.message}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">
                No new alerts
              </p>
            )}
          </div>
        </motion.div>
      </div>

      {/* Entity Distribution */}
      {structure && structure.entities.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10"
        >
          <div className="p-4 border-b border-white/10">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <MapPin className="w-5 h-5 text-purple-400" />
              Entity Distribution by Jurisdiction
            </h3>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {Object.entries(
                structure.entities.reduce((acc, entity) => {
                  acc[entity.jurisdictionCode] = (acc[entity.jurisdictionCode] || 0) + 1;
                  return acc;
                }, {} as Record<string, number>)
              ).map(([code, count]) => {
                const jurisdiction = getJurisdiction(code);
                return (
                  <div
                    key={code}
                    className="p-3 bg-white/5 rounded-lg text-center"
                  >
                    <span className="text-2xl">{jurisdiction?.flag || '🏳️'}</span>
                    <p className="text-sm font-medium text-white mt-1">
                      {jurisdiction?.shortName || code}
                    </p>
                    <p className="text-xs text-gray-500">{count} entities</p>
                    <p className="text-xs text-gray-400">
                      {jurisdiction?.corporateTax.standardRate || 0}% tax
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}

      {/* Potential Savings Card */}
      {optimizationResult && optimizationResult.potentialSavings > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 backdrop-blur-sm rounded-xl border border-emerald-500/30 p-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-emerald-500/30 rounded-xl">
                <Sparkles className="w-8 h-8 text-emerald-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Potential Tax Savings Identified</h3>
                <p className="text-gray-400">Based on AI analysis of your corporate structure</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-emerald-400 font-mono">
                ${optimizationResult.potentialSavings.toLocaleString()}
              </p>
              <p className="text-sm text-gray-400">
                {optimizationResult.potentialSavingsPercentage.toFixed(1)}% reduction possible
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

// =============================================================================
// JURISDICTIONS TAB COMPONENT
// =============================================================================

const JurisdictionsTab: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<JurisdictionType | 'ALL'>('ALL');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState<TaxJurisdictionFull | null>(null);
  const [compareMode, setCompareMode] = useState(false);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [taxableIncome, setTaxableIncome] = useState(1000000);

  const filteredJurisdictions = useMemo(() => {
    return ALL_JURISDICTIONS.filter(j => {
      const matchesSearch = searchQuery === '' ||
        j.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        j.code.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === 'ALL' || j.type === selectedType;
      return matchesSearch && matchesType;
    });
  }, [searchQuery, selectedType]);

  const comparisonResults = useMemo(() => {
    if (compareList.length === 0) return null;
    return compareJurisdictions(compareList, taxableIncome);
  }, [compareList, taxableIncome]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const toggleCompare = (code: string) => {
    setCompareList(prev => 
      prev.includes(code) 
        ? prev.filter(c => c !== code)
        : [...prev, code]
    );
  };

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">
            Tax Jurisdictions
          </h2>
          <p className="text-gray-400">
            {ALL_JURISDICTIONS.length} jurisdictions available
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search jurisdictions..."
              className="pl-10 pr-4 py-2 w-64 rounded-lg border border-white/10 bg-white/5 text-white text-sm placeholder-gray-500 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as JurisdictionType | 'ALL')}
            className="px-4 py-2 rounded-lg border border-white/10 bg-white/5 text-white text-sm focus:border-blue-500 focus:outline-none"
          >
            <option value="ALL">All Types</option>
            <option value={JurisdictionType.US_FEDERAL}>US Federal</option>
            <option value={JurisdictionType.US_STATE}>US States</option>
            <option value={JurisdictionType.US_TERRITORY}>US Territories</option>
            <option value={JurisdictionType.COUNTRY}>Countries</option>
            <option value={JurisdictionType.SPECIAL_ZONE}>Special Zones</option>
          </select>

          <button
            onClick={() => setCompareMode(!compareMode)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              compareMode
                ? 'bg-blue-500 text-white'
                : 'bg-white/5 text-gray-300 hover:bg-white/10'
            }`}
          >
            Compare Mode
          </button>
        </div>
      </div>

      {/* Comparison Panel */}
      <AnimatePresence>
        {compareMode && compareList.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden"
          >
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-white">
                  Comparing {compareList.length} Jurisdictions
                </h3>
                <div className="flex items-center gap-3">
                  <label className="text-sm text-gray-400">Taxable Income:</label>
                  <input
                    type="number"
                    value={taxableIncome}
                    onChange={(e) => setTaxableIncome(Number(e.target.value))}
                    className="w-40 px-3 py-1 rounded-lg border border-white/10 bg-white/5 text-white text-sm"
                  />
                  <button
                    onClick={() => setCompareList([])}
                    className="text-sm text-red-400 hover:text-red-300"
                  >
                    Clear All
                  </button>
                </div>
              </div>
            </div>
            
            {comparisonResults && (
              <div className="p-4 overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-sm text-gray-500">
                      <th className="pb-3 font-medium">Rank</th>
                      <th className="pb-3 font-medium">Jurisdiction</th>
                      <th className="pb-3 font-medium">Standard Rate</th>
                      <th className="pb-3 font-medium">Effective Rate</th>
                      <th className="pb-3 font-medium">Tax Amount</th>
                      <th className="pb-3 font-medium"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonResults.map((result) => {
                      const jurisdiction = getJurisdiction(result.code);
                      return (
                        <tr key={result.code} className="border-t border-white/5">
                          <td className="py-3">
                            <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                              result.ranking === 1
                                ? 'bg-green-500/20 text-green-400'
                                : result.ranking === 2
                                ? 'bg-blue-500/20 text-blue-400'
                                : 'bg-white/10 text-gray-400'
                            }`}>
                              {result.ranking}
                            </span>
                          </td>
                          <td className="py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{jurisdiction?.flag}</span>
                              <span className="font-medium text-white">
                                {result.name}
                              </span>
                            </div>
                          </td>
                          <td className="py-3 text-gray-400">
                            {result.standardRate}%
                          </td>
                          <td className="py-3">
                            <span className={`font-medium ${
                              result.effectiveRate <= 15
                                ? 'text-green-400'
                                : result.effectiveRate <= 25
                                ? 'text-yellow-400'
                                : 'text-red-400'
                            }`}>
                              {result.effectiveRate.toFixed(2)}%
                            </span>
                          </td>
                          <td className="py-3 font-medium text-white font-mono">
                            {formatCurrency(result.taxAmount)}
                          </td>
                          <td className="py-3">
                            <button
                              onClick={() => toggleCompare(result.code)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
          <h4 className="text-sm text-gray-400 mb-2">
            No Income Tax Jurisdictions
          </h4>
          <div className="flex flex-wrap gap-2">
            {getNoIncomeTaxStates().slice(0, 5).map(j => (
              <span
                key={j.code}
                className="text-xs px-2 py-1 rounded bg-green-500/20 text-green-400"
              >
                {j.flag} {j.shortName}
              </span>
            ))}
            {getNoIncomeTaxStates().length > 5 && (
              <span className="text-xs px-2 py-1 text-gray-500">
                +{getNoIncomeTaxStates().length - 5} more
              </span>
            )}
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
          <h4 className="text-sm text-gray-400 mb-2">
            Low Tax Countries (≤15%)
          </h4>
          <div className="flex flex-wrap gap-2">
            {getLowTaxJurisdictions(15).slice(0, 5).map(j => (
              <span
                key={j.code}
                className="text-xs px-2 py-1 rounded bg-blue-500/20 text-blue-400"
              >
                {j.flag} {j.shortName} ({j.corporateTax.standardRate}%)
              </span>
            ))}
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
          <h4 className="text-sm text-gray-400 mb-2">
            Total Jurisdictions by Type
          </h4>
          <div className="space-y-1 text-sm text-gray-300">
            <p>US States: {ALL_JURISDICTIONS.filter(j => j.type === JurisdictionType.US_STATE).length}</p>
            <p>Countries: {ALL_JURISDICTIONS.filter(j => j.type === JurisdictionType.COUNTRY).length}</p>
            <p>Territories: {ALL_JURISDICTIONS.filter(j => j.type === JurisdictionType.US_TERRITORY).length}</p>
          </div>
        </div>
      </div>

      {/* Jurisdictions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredJurisdictions.slice(0, 30).map((jurisdiction) => (
          <motion.div
            key={jurisdiction.code}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`bg-white/5 backdrop-blur-sm rounded-xl border transition-all cursor-pointer ${
              compareMode && compareList.includes(jurisdiction.code)
                ? 'border-blue-500 ring-2 ring-blue-500/20'
                : 'border-white/10 hover:border-white/20'
            }`}
            onClick={() => {
              if (compareMode) {
                toggleCompare(jurisdiction.code);
              } else {
                setSelectedJurisdiction(jurisdiction);
              }
            }}
          >
            <div className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{jurisdiction.flag || '🏳️'}</span>
                  <div>
                    <h3 className="font-semibold text-white">
                      {jurisdiction.name}
                    </h3>
                    <p className="text-xs text-gray-500">{jurisdiction.code}</p>
                  </div>
                </div>
                {compareMode && (
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    compareList.includes(jurisdiction.code)
                      ? 'bg-blue-500 border-blue-500'
                      : 'border-gray-600'
                  }`}>
                    {compareList.includes(jurisdiction.code) && (
                      <CheckCircle2 className="w-3 h-3 text-white" />
                    )}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 mt-4">
                <div>
                  <p className="text-xs text-gray-500">Corporate Tax</p>
                  <p className={`text-lg font-bold ${
                    jurisdiction.corporateTax.standardRate === 0
                      ? 'text-green-400'
                      : jurisdiction.corporateTax.standardRate <= 15
                      ? 'text-blue-400'
                      : jurisdiction.corporateTax.standardRate <= 25
                      ? 'text-yellow-400'
                      : 'text-red-400'
                  }`}>
                    {jurisdiction.corporateTax.standardRate}%
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">DTAs</p>
                  <p className="text-lg font-bold text-white">
                    {jurisdiction.dtaPartners.length}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1 mt-3">
                {jurisdiction.noIncomeTax && (
                  <span className="text-xs px-2 py-0.5 rounded bg-green-500/20 text-green-400">
                    No Income Tax
                  </span>
                )}
                {jurisdiction.territorialSystem && (
                  <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-400">
                    Territorial
                  </span>
                )}
                {jurisdiction.taxIncentives && jurisdiction.taxIncentives.length > 0 && (
                  <span className="text-xs px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400">
                    Incentives
                  </span>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredJurisdictions.length > 30 && (
        <p className="text-center text-gray-500">
          Showing 30 of {filteredJurisdictions.length} jurisdictions. Use search to find more.
        </p>
      )}

      {/* Jurisdiction Detail Modal */}
      <AnimatePresence>
        {selectedJurisdiction && !compareMode && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
            onClick={(e) => e.target === e.currentTarget && setSelectedJurisdiction(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-white/10"
            >
              <div className="p-6 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{selectedJurisdiction.flag}</span>
                  <div>
                    <h2 className="text-xl font-bold text-white">
                      {selectedJurisdiction.name}
                    </h2>
                    <p className="text-sm text-gray-500">{selectedJurisdiction.code}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedJurisdiction(null)}
                  className="p-2 hover:bg-white/10 rounded-lg text-gray-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Tax Rates */}
                <div>
                  <h3 className="font-semibold text-white mb-3">Tax Rates</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-3 bg-white/5 rounded-lg">
                      <p className="text-xs text-gray-500">Corporate Tax</p>
                      <p className="text-xl font-bold text-white">
                        {selectedJurisdiction.corporateTax.standardRate}%
                      </p>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <p className="text-xs text-gray-500">WHT Dividends</p>
                      <p className="text-xl font-bold text-white">
                        {selectedJurisdiction.withholdingTax.dividends}%
                      </p>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <p className="text-xs text-gray-500">WHT Interest</p>
                      <p className="text-xl font-bold text-white">
                        {selectedJurisdiction.withholdingTax.interest}%
                      </p>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <p className="text-xs text-gray-500">WHT Royalties</p>
                      <p className="text-xl font-bold text-white">
                        {selectedJurisdiction.withholdingTax.royalties}%
                      </p>
                    </div>
                  </div>
                </div>

                {/* Transfer Pricing */}
                <div>
                  <h3 className="font-semibold text-white mb-3">Transfer Pricing</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Documentation Required</span>
                      <span className={selectedJurisdiction.transferPricingRules.documentationRequired ? 'text-green-400' : 'text-gray-600'}>
                        {selectedJurisdiction.transferPricingRules.documentationRequired ? 'Yes' : 'No'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Master File</span>
                      <span className={selectedJurisdiction.transferPricingRules.masterFileRequired ? 'text-green-400' : 'text-gray-600'}>
                        {selectedJurisdiction.transferPricingRules.masterFileRequired ? 'Yes' : 'No'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">CbC Reporting</span>
                      <span className={selectedJurisdiction.transferPricingRules.cbcReportingRequired ? 'text-green-400' : 'text-gray-600'}>
                        {selectedJurisdiction.transferPricingRules.cbcReportingRequired ? 'Yes' : 'No'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">APA Available</span>
                      <span className={selectedJurisdiction.transferPricingRules.advancePricingAgreements ? 'text-green-400' : 'text-gray-600'}>
                        {selectedJurisdiction.transferPricingRules.advancePricingAgreements ? 'Yes' : 'No'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* DTAs */}
                {selectedJurisdiction.dtaPartners.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-white mb-3">
                      Double Tax Agreements ({selectedJurisdiction.dtaPartners.length})
                    </h3>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {selectedJurisdiction.dtaPartners.slice(0, 10).map((dta) => (
                        <div key={dta.partnerJurisdictionCode} className="flex items-center justify-between p-2 bg-white/5 rounded text-sm">
                          <span className="font-medium text-white">{dta.partnerJurisdictionName}</span>
                          <div className="flex gap-4 text-xs text-gray-400">
                            <span>Div: {dta.dividendsRate}%</span>
                            <span>Int: {dta.interestRate}%</span>
                            <span>Roy: {dta.royaltiesRate}%</span>
                          </div>
                        </div>
                      ))}
                      {selectedJurisdiction.dtaPartners.length > 10 && (
                        <p className="text-xs text-gray-500 text-center">
                          +{selectedJurisdiction.dtaPartners.length - 10} more treaties
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {/* Tax Incentives */}
                {selectedJurisdiction.taxIncentives && selectedJurisdiction.taxIncentives.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-white mb-3">Tax Incentives</h3>
                    <div className="space-y-2">
                      {selectedJurisdiction.taxIncentives.map((incentive, i) => (
                        <div key={i} className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                          <p className="font-medium text-white">{incentive.name}</p>
                          <p className="text-sm text-gray-400 mt-1">{incentive.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// =============================================================================
// MAIN TAX PAGE COMPONENT
// =============================================================================

export default function TaxPage() {
  const [activeTab, setActiveTab] = useState<TabId>('overview');

  // Initialize demo data on mount
  useEffect(() => {
    initializeDemoTaxData();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-teal-500/20 to-cyan-600/10 border border-teal-500/20">
              <Calculator className="w-6 h-6 text-teal-400" />
            </div>
            Tax Center
          </h1>
          <p className="text-gray-400 mt-1">International tax compliance and optimization</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setActiveTab('optimization')}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl font-medium text-white shadow-lg shadow-emerald-500/25"
        >
          <Sparkles className="w-5 h-5" />
          AI Tax Analysis
        </motion.button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-white/5 rounded-xl w-fit">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id 
                  ? 'bg-white/10 text-white' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {activeTab === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <OverviewTab />
          </motion.div>
        )}

        {activeTab === 'structure' && (
          <motion.div
            key="structure"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <CorporateStructureEditor />
          </motion.div>
        )}

        {activeTab === 'jurisdictions' && (
          <motion.div
            key="jurisdictions"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <JurisdictionsTab />
          </motion.div>
        )}

        {activeTab === 'optimization' && (
          <motion.div
            key="optimization"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <TaxOptimizationPanel />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
